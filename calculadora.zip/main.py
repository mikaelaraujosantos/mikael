import os  # Importe o módulo os para limpar a tela do terminal

# Defina as taxas de câmbio
taxa_dolar_para_real = 5.50  # Exemplo: 1 USD = 5.50 BRL
taxa_euro_para_real = 6.50  # Exemplo: 1 EUR = 6.50 BRL

# Função para converter de dólar para real
def converter_dolar_para_real(valor_em_dolar):
    return round(valor_em_dolar * taxa_dolar_para_real, 1)

# Função para converter de euro para real
def converter_euro_para_real(valor_em_euro):
    return round(valor_em_euro * taxa_euro_para_real, 1)

# Função para converter de real para dólar
def converter_real_para_dolar(valor_em_real):
    return round(valor_em_real / taxa_dolar_para_real, 1)

# Função para converter de real para euro
def converter_real_para_euro(valor_em_real):
    return round(valor_em_real / taxa_euro_para_real, 1)

# Função para converter de euro para dólar
def converter_euro_para_dolar(valor_em_euro):
    return round(valor_em_euro / taxa_dolar_para_real, 1)

while True:
    os.system('cls' if os.name == 'nt' else 'clear')  # Limpar a tela do terminal

    # Solicite ao usuário que escolha uma operação
    print("Moedas disponíveis:")
    print("1. Dólar (USD)")
    print("2. Euro (EUR)")
    print("3. Real (BRL)")
    print("4. Sair")

    origem = int(input("Informe a moeda de origem:"))

    if origem == 4:
        break  # Sair do programa

    # Configurar o menu da segunda solicitação com base na moeda de origem selecionada
    print("Moeda de destino:")
    if origem == 1:
        print("1. Euro (EUR)")
        print("2. Real (BRL)")
    elif origem == 2:
        print("1. Dólar (USD)")
        print("2. Real (BRL)")
    elif origem == 3:
        print("1. Dólar (USD)")
        print("2. Euro (EUR)")

    destino = int(input("Informe a moeda de destino: "))                   
    valor_origem = float(input("Digite o valor a ser convertido: "))

    if origem == 1 and destino == 2:
        resultado = converter_dolar_para_real(valor_origem)
        print(f"O valor em reais é: {resultado:.1f} BRL")
    elif origem == 1 and destino == 1:
        resultado = valor_origem
        print(f"O valor em dólar é: {resultado:.1f} USD")
    elif origem == 2 and destino == 1:
        resultado = converter_euro_para_dolar(valor_origem)
        print(f"O valor em dólar é: {resultado:.1f} USD")
    elif origem == 2 and destino == 2:
        resultado = valor_origem
        print(f"O valor em euro é: {resultado:.1f} EUR")
    elif origem == 3 and destino == 1:
        resultado = converter_real_para_dolar(valor_origem)
        print(f"O valor em dólar é: {resultado:.1f} USD")
    elif origem == 3 and destino == 2:
        resultado = converter_real_para_euro(valor_origem)
        print(f"O valor em euro é: {resultado:.1f} EUR")
    else:
        print("Conversão não suportada para a combinação de moedas selecionada.")

    continuar = input(
        "Deseja continuar? (S para sim, qualquer outra tecla para sair): "
    ).strip()
    if continuar.upper() != 'S':
        break  # Sair do programa
